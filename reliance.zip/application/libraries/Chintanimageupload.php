<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 


class Chintanimageupload {

    private $CI;
    function __construct()
    {
        // Assign by reference with "&" so we don't create a copy
        $this->CI = &get_instance();
    }
    public function makeheader()
    {
		
    }
	
}

/* End of file Someclass.php */